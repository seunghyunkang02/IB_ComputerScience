<?php
echo "Hi ".$_GET["name"].", You have slept for ".$_GET["awake"-"sleep"]."!";
?>